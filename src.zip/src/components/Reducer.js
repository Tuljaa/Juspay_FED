import { createSlice } from '@reduxjs/toolkit'

export const Reducer = createSlice({

    
   
  name: 'counter',
  initialState: {
      num:0,
    value: 0
  },

  reducers: {
    turn: state => {
        state.num=state.num+1
        switch(state.num%5){
            
            case 1: state.value ="transform rotate-45 ..."
                break
            case 2: state.value ="transform rotate-90 ..."
                break
            case 3: state.value ="transform rotate-180 ..."
                break
            case 4: state.value ="transform -rotate-45 ..."
            break
        }
      
    },
    rotate: state => {
        state.num=state.num+1
        switch(state.num%5){
            
            case 1: state.value ="transform -rotate-45 ..."
                break
            case 2: state.value ="transform -rotate-90 ..."
                break
            case 3: state.value ="transform -rotate-180 ..."
                break
            case 4: state.value ="transform -rotate-0 ..."
                break

        }
        state.value="transform translate-x-4 ..."
    },
    move: state => {
        state.num=state.num+1
        switch(state.num%5){
            
            case 1: state.value ="transform translate-x-4 ..."
                break
            case 2: state.value ="transform translate-x-8 ..."
                break
            case 3: state.value ="transform translate-x-12 ..."
                break
            case 4: state.value ="transform translate-x-16 ..."
                break

        }
  
    },
    sayhello: state=> {
             state.value ="Hello"
    },
    think: state=> {
        state.value ="Hmm"
}
    
  }
})

// Action creators are generated for each case reducer function
export const { turn, move, rotate, sayhello, think } = Reducer.actions

export default Reducer.reducer