import React from "react";
import Sidebar from "./Sidebar";
export default function MidArea() {
  return (

      <div className="flex-1 h-full overflow-auto">{"MID area"} 

  </div>
  );
}
